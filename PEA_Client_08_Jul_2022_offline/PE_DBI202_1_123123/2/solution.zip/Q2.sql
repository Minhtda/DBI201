SELECT *
FROM Product
WHERE SellEndDate like '%2003%'